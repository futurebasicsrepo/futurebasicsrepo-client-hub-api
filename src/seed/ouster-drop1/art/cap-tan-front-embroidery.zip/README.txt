Ouster lockup, stacked: cap front · Satin stitch embroidery · 2.75 × 1.45 in (70 × 37 mm) at 300 dpi
Files:
  artwork-300dpi.png
  ink-01-white.png
  ouster-lockup-stacked-ca.dst
  ouster-lockup-stacked-ca.exp
  stitch-preview.png
  job.json
  job-sheet.pdf
job-sheet.pdf is the one page to pin up. job.json holds the same as data. Every ink-*.png is one colour on a clear ground; every film-*.png is its black-on-white film positive at 300 dpi, with registration marks in a half-inch margin (gradients screened as halftone dots at the angle on the sheet).
The stitch file is ouster-lockup-stacked-ca.dst (Tajima, any machine) and ouster-lockup-stacked-ca.exp (Melco); stitch-preview.png shows it sewn. Run a sew-out before production.
Satin stitch, 40 wt polyester or rayon thread, tear-away backing; give thread colours as Madeira or Pantone references.
