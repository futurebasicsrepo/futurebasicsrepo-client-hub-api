Ouster mark: left chest · Plastisol screen print · 1.25 × 0.81 in (32 × 21 mm) at 300 dpi
Files:
  artwork-300dpi.png
  ink-01-pantone-neutral-black-c.png
  film-01-pantone-neutral-black-c.png
  job.json
  job-sheet.pdf
job-sheet.pdf is the one page to pin up. job.json holds the same as data. Every ink-*.png is one colour on a clear ground; every film-*.png is its black-on-white film positive at 300 dpi, with registration marks in a half-inch margin (gradients screened as halftone dots at the angle on the sheet).
Plastisol inks, one screen per colour, white underbase on dark garments.
